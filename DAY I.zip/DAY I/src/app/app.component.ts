import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  courses:Course[]=[
    new Course("Node","3 Days"),
    new Course("React","4 Days"),
    new Course("Polymer","4 Days")
  ];
}
