let aVar:string = "ES 6 !";

function Addition(x:any,y:any){
    return x + y;
}