var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 100; // Type Inference 
//x = "Hi";
var y; // Type annotation !
var b;
var s;
var z;
z = 10;
z = "Hello !";
z = { name: 'Gemalto' };
z = [10, 20, 30];
function Add(x, y) {
    if (x < 0) {
        return 'x should be greater than 0 !';
    }
    return x + y;
}
var result = Add(20, 30);
// let & const -> ES 6 | ES 2015
var scopedVar = 2000;
// var scopedVar = 3000;
if (true) {
    var scopedVar_1 = 1000;
    // 100 lines of code
    // let scopedVar = 1000; // Error !
    console.log(scopedVar_1);
    if (true) {
        console.log(scopedVar_1);
    }
}
//console.log(scopedVar);
var PI = 3.14;
// PI = 3.14565;
// Arrays 
var cars = ['BMW', 'AUDI', 'FERRARI'];
var moreCars = new Array('TATA', 'MAHINDRA', 'MARUTI');
// Spread Operator
var allCars = cars.concat(moreCars);
console.log(allCars);
// Iterating Constructs
// for
// for-in
for (var c_1 in cars) {
    console.log(cars[c_1]);
}
// for-of
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var c_2 = cars_1[_i];
    console.log(c_2);
}
// forEach
allCars.forEach(function (car, i) {
    console.log(i + ". " + car);
});
// Functions
// function Square(x){
//         return x * x;
// }
// function as an expression !
// var Square = function(x){
//     return x *x;
// };
// ES 6 & Typescript (Arrow Functions) == Lambda Expression
// var Square = (x) => {
//     return x * x;
// }
// OR
var Square = function (x) { return x * x; };
allCars.forEach(function (car, i) {
    console.log(i + ". " + car);
});
// OR
allCars.forEach(function (car, i) { return console.log(i + ". " + car); });
// Parameters
//1. Optional
// function PrintBooks(author?:string,title?:string,noOfPages?:number){
//     author = author || "Unknown";
//     title = title || "Unknown";
//     noOfPages = noOfPages || 0;
//         console.log(author,title,noOfPages);
// }
// 2.Default
// function PrintBooks(author:string="Unknown",title:string="Unknown",
// noOfPages:number=0){ 
//         console.log(author,title,noOfPages);
// }
// PrintBooks();
// PrintBooks("Dr. APJ Abdul Kalam");
// PrintBooks(undefined,"Wings Of Fire",undefined);
// PrintBooks("Dr. APJ Abdul Kalam","Wings Of Fire",300);
//3. Rest Parameters
function PrintBooks(author) {
    var titles = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        titles[_i - 1] = arguments[_i];
    }
    console.log(author, titles);
}
PrintBooks("Sachin Tendulkar", "Playing It My Way");
PrintBooks("Dr. APJ Abdul Kalam", "India 2020", "Wings Of Fire");
var company = { name: 'Gemalto' };
// classes
var Car = /** @class */ (function () {
    function Car(theName, theSpeed) {
        if (theName === void 0) { theName = "i20"; }
        if (theSpeed === void 0) { theSpeed = 200; }
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.accelerate = function () {
        // console.log(this.name +  " running at " + this.speed + " kmph !");
        return (this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
// var str = `fngndfjndjgnjfgnf
// ;fkgkfngng
// ;dkfgksngknsg
// dksfndknffnkf
// `
var carObj = new Car();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(theName, theSpeed, fly, nitro) {
        var _this = _super.call(this, theName, theSpeed) || this;
        _this.canFly = fly;
        _this.nitroPower = nitro;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " Can It Fly ? : " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 400, true, true);
console.log(jbc.accelerate());
var Company = /** @class */ (function () {
    function Company() {
    }
    return Company;
}());
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.getSalary = function () {
        return this.salary;
    };
    return Employee;
}());
// Enhanced Class Syntax
var CarClass = /** @class */ (function () {
    function CarClass(name, speed) {
        this.name = name;
        this.speed = speed;
    }
    return CarClass;
}());
var c = new CarClass("i20", 200);
