var x = 100;  // Type Inference 
//x = "Hi";

var y:number; // Type annotation !
var b:boolean;
var s:string;
var z;
z = 10;
z = "Hello !";
z= {name:'Gemalto'};
z = [10,20,30];

function Add(x:number,y:number):number|string{
    if(x < 0){
        return 'x should be greater than 0 !'
    }
        return x + y;
}

var result:number|string = Add(20,30);

// let & const -> ES 6 | ES 2015

 var scopedVar = 2000;
// var scopedVar = 3000;

if(true){
    let scopedVar = 1000;
        // 100 lines of code
   // let scopedVar = 1000; // Error !
    console.log(scopedVar);
    if(true){
            console.log(scopedVar);
    }
}

//console.log(scopedVar);

const PI = 3.14;
// PI = 3.14565;

// Arrays 

var cars:string[] = ['BMW','AUDI','FERRARI'];
var moreCars:Array<string> = new Array<string>('TATA','MAHINDRA','MARUTI');
// Spread Operator
var allCars:string[] = [...cars,...moreCars];
console.log(allCars);

// Iterating Constructs

// for
// for-in
for(let c in cars){
    console.log(cars[c]);
}

// for-of
for(let c of cars){
    console.log(c);
}

// forEach
allCars.forEach(function(car,i){
        console.log(i + ". " + car);
});

// Functions

// function Square(x){
//         return x * x;
// }

// function as an expression !
// var Square = function(x){
//     return x *x;
// };

// ES 6 & Typescript (Arrow Functions) == Lambda Expression
// var Square = (x) => {
//     return x * x;
// }

// OR

var Square = (x:number) => x * x;

allCars.forEach(function(car,i){
    console.log(i + ". " + car);
});

// OR

allCars.forEach((car,i)=>console.log(i + ". " + car));


// Parameters
//1. Optional

// function PrintBooks(author?:string,title?:string,noOfPages?:number){
//     author = author || "Unknown";
//     title = title || "Unknown";
//     noOfPages = noOfPages || 0;
//         console.log(author,title,noOfPages);
// }

// 2.Default

// function PrintBooks(author:string="Unknown",title:string="Unknown",
// noOfPages:number=0){ 
//         console.log(author,title,noOfPages);
// }

// PrintBooks();
// PrintBooks("Dr. APJ Abdul Kalam");
// PrintBooks(undefined,"Wings Of Fire",undefined);
// PrintBooks("Dr. APJ Abdul Kalam","Wings Of Fire",300);

//3. Rest Parameters
function PrintBooks(author:string,...titles:string[]){ 
        console.log(author,titles);
}

PrintBooks("Sachin Tendulkar","Playing It My Way");
PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");

// Interfaces

interface ICompany{
    name:string;
    location?:string;
}

var company:ICompany = {name:'Gemalto'};

// classes

class Car{
    private id:number;
    name:string;
    speed:number;
    constructor(theName:string="i20",theSpeed:number=200){
        this.name = theName;
        this.speed = theSpeed;
    }

    accelerate():string{
            // console.log(this.name +  " running at " + this.speed + " kmph !");
            return (`${this.name} is running at ${this.speed} kmph !`);
    }
}
// var str = `fngndfjndjgnjfgnf
// ;fkgkfngng
// ;dkfgksngknsg
// dksfndknffnkf
// `
var carObj = new Car();

class JamesBondCar extends Car{
    canFly:boolean;
    nitroPower:boolean;
    constructor(theName:string,theSpeed:number,fly:boolean,nitro:boolean){
        super(theName,theSpeed);
        this.canFly = fly;
        this.nitroPower =nitro;
    }

    accelerate():string{
            return super.accelerate() + " Can It Fly ? : " + this.canFly;
    }
}

var jbc = new JamesBondCar("Aston Martin",400,true,true);
console.log(jbc.accelerate())   ;

class Company implements ICompany{
    name:string;
    location:string;
}

interface IEmployee{
    id:number;
    name:string;
   email:string;
   salary:number;
   getSalary():number;
}

class Employee implements IEmployee{
    id:number;
    name:string;
   email:string;
   salary:number;

   getSalary():number{
                return this.salary;
   }
}

// Enhanced Class Syntax

class CarClass{
    constructor(public name:string,public speed:number){

    }
}

var c = new CarClass("i20",200);


