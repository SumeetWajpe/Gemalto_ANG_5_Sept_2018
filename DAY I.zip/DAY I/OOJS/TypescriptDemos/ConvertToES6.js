var aVar = "ES 6 !";
function Addition(x, y) {
    return x + y;
}
