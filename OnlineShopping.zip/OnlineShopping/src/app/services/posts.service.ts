import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Post } from '../models/post.model';

@Injectable()
export class PostsService{
    
    constructor(public httpObj:HttpClient){

    }
    // Using Observables !
    // getAllPosts():Observable<Post[]>{
    //     // make an ajax request here !
    //  return   this.httpObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts');
       
    // }



// Using Promises !
    getAllPosts(){
        // make an ajax request here !
     return this.httpObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts').toPromise();
       
    }
}