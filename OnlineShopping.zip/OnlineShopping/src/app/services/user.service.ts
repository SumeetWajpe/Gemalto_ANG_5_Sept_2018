export class UserService{
    private isUserLoggedIn:boolean;

    constructor(){
        this.isUserLoggedIn = false;
    }

    setUserLoggedIn(){
        // make ajax request here !
        this.isUserLoggedIn = true;
    }

    getUserLoggedIn(){
        return this.isUserLoggedIn;
    }
}