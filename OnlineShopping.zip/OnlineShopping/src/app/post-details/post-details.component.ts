import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Post } from '../models/post.model';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {

   postId:number;
   currFetchPost:Post = new Post();
  constructor(public currRoute:ActivatedRoute) { }

  ngOnInit() {

    this.currRoute.params.subscribe(
        p => this.postId = p["id"]
    )

    let fetchedPosts = JSON.parse( localStorage["posts"]);
    this.currFetchPost =  fetchedPosts.find(
         (p:Post)=>{
                 return p.id == this.postId
         }
     )
  }

}
