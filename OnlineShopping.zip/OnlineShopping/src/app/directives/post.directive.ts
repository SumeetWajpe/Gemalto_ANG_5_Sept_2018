import { Directive, ElementRef, Input,HostListener,Renderer2 } from "@angular/core";


@Directive({
    selector:`[poststyle]`
})
export class PostDirective{

     @Input() postBGColor:string="yellow";
    constructor(public refElement:ElementRef,
        public rendererObj:Renderer2){}

    ngOnInit(){
        this.refElement.nativeElement.style.backgroundColor = this.postBGColor;
        this.refElement.nativeElement.style.border = '2px solid red'
        this.refElement.nativeElement.style.borderRadius = "10px";
        this.refElement.nativeElement.style.margin = "20px";
        this.refElement.nativeElement.style.padding = "10px";  
    }

    @HostListener('mouseenter')  OnMouseEnter(){
        this.refElement.nativeElement.style.backgroundColor = "lightgreen";
        this.refElement.nativeElement.className = "OnHover";

    }
    @HostListener('mouseleave')  OnMouseLeave(){
        this.refElement.nativeElement.style.backgroundColor = this.postBGColor;
    }

    @HostListener('click')  OnClick(){
            var pElement = this.rendererObj.createElement('p');
            var textElement = this.rendererObj.createText("Please click the Link !");
            this.rendererObj.addClass(pElement,"Highlight");
            this.rendererObj.appendChild(pElement,textElement);
            this.rendererObj.appendChild(this.refElement.nativeElement,pElement);
    }


}