
import {Pipe,PipeTransform} from '@angular/core';

@Pipe({
    name:'qty'
})
export class QuantityPipe implements PipeTransform{
        transform(theInputQuantity:number,theParams:string){
                // return ` ${theInputQuantity} [${theParams}] `

                switch(theInputQuantity){
                    case 0:
                        return ` Out Of Stock ! `;
                    default:
                         return ` ${theInputQuantity} [${theParams}] `
                }
        }
}