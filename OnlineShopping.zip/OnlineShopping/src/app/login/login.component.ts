import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  inputName:string="";
  inputPassword:string="";
  isUserInValid:boolean = false;
  constructor(public router:Router,public userServObj:UserService) { }
  ngOnInit() {  }
  ValidateUser(){
    if(this.inputName == "admin" && this.inputPassword == "admin"){   
      this.userServObj.setUserLoggedIn();  
      // navigate user to dashboard !
      this.router.navigate(['/dashboard']);
    }
    else{
      this.isUserInValid = true;
    }
  }

}
