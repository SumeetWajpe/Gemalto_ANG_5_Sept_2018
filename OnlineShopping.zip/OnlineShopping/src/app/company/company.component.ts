import { Component, OnInit, Input, OnChanges, SimpleChanges, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit,OnChanges,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy {

  @Input() name:string="Unknown";
  constructor() {
    console.log('Constructor called  !');
    console.log('name : ' + this.name);
   }   
   ngOnChanges(theChanges:SimpleChanges){
    console.log('ngOnChanges called  !');
    console.log('name : ' + this.name);

    for(let prop in theChanges){
      console.log(` Property Name : ${prop} , Current Value : ${theChanges[prop].currentValue} , Previous Value : ${theChanges[prop].previousValue}`);
    }

   }
  ngOnInit() {
    console.log('ngOnInit called  !');
    console.log('name : ' + this.name);
  }

  ngAfterContentChecked(){
    console.log('ngAfterContentChecked called  !');

  }

  ngAfterContentInit(){
    console.log('ngAfterContentInit called  !');
  }

  ngAfterViewChecked(){
    console.log('ngAfterViewChecked called  !');
  }
  ngAfterViewInit(){
    console.log('ngAfterViewInit called  !');
  }

  ngOnDestroy(){
    console.log('ngOnDestroy called  !');
  }


}
