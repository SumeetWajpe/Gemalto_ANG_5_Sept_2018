import { Component, OnInit } from '@angular/core';
import { PostsService } from '../services/posts.service';
import { Post } from '../models/post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css'],
  providers:[PostsService]
})
export class PostsComponent implements OnInit {

  posts:Post[]=[];
  constructor(public postServObj:PostsService) { 
   
    this.posts = JSON.parse(localStorage["posts"]);

  //  this.postServObj.getAllPosts().subscribe(
  //       (response)=>{      
  //        this.posts = response;
  //        },
  //       (err)=>console.log(err)
  //  );// eof subscribe !


    //let aPromise = this.postServObj.getAllPosts();
    //aPromise.then(
       //    (response)=> {
          //   this.posts = JSON.parse(localStorage["posts"]);
           // this.posts = response ;
           // localStorage["posts"] = JSON.stringify(this.posts)
       //    }         ,
      //     (err)=>console.log(err)
    //);// eof then !
   }

  ngOnInit() {
  }

}
