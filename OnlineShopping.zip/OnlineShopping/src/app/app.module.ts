import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { ProductComponent } from './product/product.component';
import { QuantityPipe } from './pipes/quantity.pipe';
import { CourseComponent } from './course/course.component';
import { CourseService } from './services/course.service';
import { PostsComponent } from './posts/posts.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { UserService } from './services/user.service';
import { UserauthGuard } from './userauth.guard';
import { CompanyComponent } from './company/company.component';
import { PostDirective } from './directives/post.directive';

/* Older configuration (without gaurds) */
// var routes:Routes = [
//   {path:'cart',component:ShoppingCartComponent},
//   {path:'posts',component:PostsComponent},
//   {path:'course',component:CourseComponent},
//   {path:'posts/:id',component:PostDetailsComponent},
//   {path:'',redirectTo:'/cart',pathMatch:'full'},
//   {path:'**',redirectTo:'/posts'}
// ];

var routes:Routes = [
    {path:'',component:LoginComponent},
    {
      path:'dashboard',
      component:DashboardComponent,
     // canActivate:[UserauthGuard], // associate the gaurd with the route !
      children:[
        {path:'',component:PostsComponent},
        {path:'cart',component:ShoppingCartComponent},
        {path:'posts/:id',component:PostDetailsComponent}
      ]
    }
];

@NgModule({  declarations: [
    AppComponent,    ShoppingCartComponent,    ProductComponent,    QuantityPipe,
    CourseComponent,    PostsComponent, PostDetailsComponent, 
    DashboardComponent, LoginComponent, CompanyComponent,PostDirective  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers: [CourseService,UserService,UserauthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
