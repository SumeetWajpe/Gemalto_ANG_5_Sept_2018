import { Component, OnInit } from '@angular/core';
import { PostsService } from '../services/posts.service';
import { Post } from '../models/post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css'],
  providers:[PostsService]
})
export class PostsComponent implements OnInit {

  posts:Post[]=[];
  constructor(public postServObj:PostsService) { 
   this.postServObj.getAllPosts().subscribe(
        (response)=>{      
         this.posts = response;
         },
        (err)=>console.log(err)
   );// eof subscribe !
   }

  ngOnInit() {
  }

}
