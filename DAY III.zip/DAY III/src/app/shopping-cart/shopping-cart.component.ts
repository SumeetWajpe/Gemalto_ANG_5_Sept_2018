import { Component, OnInit } from '@angular/core';
import { Product } from '../models/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css'],
  providers:[ProductService]
})
export class ShoppingCartComponent implements OnInit {

  heading:string="Online Shopping !";
  newProduct:Product = new Product();
  productName:string="";
  products:Product[] = [];
  constructor(public servObj:ProductService) { 
    this.products = servObj.getAllProducts(); // data from service !
  }

  ngOnInit() {
  }

  ChangeHeading(){
        this.heading = "Flipkart !"
  }

  ChangeHeadingOnInput(e:any){
     this.heading = e.target.value;
  }

  OnFormSubmit(theForm:any){   

    if(theForm.valid){
      this.newProduct.likes = +(this.newProduct.likes);// convert string to number
      this.products.push(this.newProduct);
      this.newProduct = new Product();
      theForm.reset();
    }
  }

  RemoveProductHandler(theIndex:number){
        this.products.splice(theIndex,1); // remove the element
  }

}
