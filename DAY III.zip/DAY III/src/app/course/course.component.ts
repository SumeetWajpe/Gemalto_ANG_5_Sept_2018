import { Component, OnInit } from '@angular/core';
import { CourseService } from '../services/course.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
  // ,providers:[CourseService] // Component level injection !
})
export class CourseComponent implements OnInit {

  listOfCourses:string[] = [];
  courseToBeAdded:string="";
  // Dependency Injection !
  constructor(public courseServObj:CourseService) { 
      this.listOfCourses = courseServObj.getAllCourses();
  }

  ngOnInit() {
  }

  AddCourse(){
    this.courseServObj.addNewCourses(this.courseToBeAdded)
  }

}
