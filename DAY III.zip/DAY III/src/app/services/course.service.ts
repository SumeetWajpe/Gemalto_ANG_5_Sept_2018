export class CourseService{
    private courses:string[] =['React','Node','Angular'];

    getAllCourses():string[]{
            return this.courses;
    }
    addNewCourses(theNewCourse:string){
            this.courses.push(theNewCourse);
    }

}