import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { Product } from '../models/product';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  @Input() productdetails:Product = new Product();
  @Input() productIndex:number ;
  @Output() removeProductEvent:EventEmitter<number> = new EventEmitter<number>();
  isStyled:boolean=true;
  isFree:boolean=true;

  constructor() { }

  ngOnInit() {
  }

  LikeProduct(){
    this.productdetails.likes +=1;
  }

  DislikeProduct(){
    this.productdetails.likes-=1;
  }

  DeleteProduct(){
    // emit the event !
    this.removeProductEvent.emit(this.productIndex);
  }

}
